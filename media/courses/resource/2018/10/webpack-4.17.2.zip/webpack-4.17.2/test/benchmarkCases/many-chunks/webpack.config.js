module.exports = {
	entry: "./index"
};
