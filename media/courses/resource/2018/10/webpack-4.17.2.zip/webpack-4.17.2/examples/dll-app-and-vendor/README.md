This example shows how to use the DllPlugin to separate vendor and app build.

This can boost the speed of the app build because vendors are no longer included, but built separately.

See [vendor part](0-vendor) and [app part](1-app).

[DllPlugin documentation](https://webpack.js.org/plugins/dll-plugin)

> Based on this gist: https://gist.github.com/Eoksni/83d1f1559e0ec00d0e89c33a6d763049 by Eoksni
