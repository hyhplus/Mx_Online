
# example.js

``` javascript
{{example.js}}
```

# worker.js

``` javascript
{{worker.js}}
```

# dist/output.js

``` javascript
{{dist/output.js}}
```

# dist/[hash].worker.js

``` javascript
{{dist/hash.worker.js}}
```

# dist/0.[hash].worker.js

``` javascript
{{dist/0.hash.worker.js}}
```

# Info

## Unoptimized

```
{{stdout}}
```

## Production mode

```
{{production:stdout}}
```
