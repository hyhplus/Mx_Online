console.log(__("Hello World"));
console.log(__("Missing Text"));