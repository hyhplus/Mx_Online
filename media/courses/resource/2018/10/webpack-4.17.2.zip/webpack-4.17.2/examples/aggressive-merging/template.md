# pageA.js

``` javascript
{{pageA.js}}
```

# pageB.js

``` javascript
{{pageB.js}}
```

# pageC.js

``` javascript
{{pageC.js}}
```

# common.js

a big file...

# webpack.config.js

``` javascript
{{webpack.config.js}}
```

# Info

## Unoptimized

```
{{stdout}}
```

## Production mode

```
{{production:stdout}}
```
