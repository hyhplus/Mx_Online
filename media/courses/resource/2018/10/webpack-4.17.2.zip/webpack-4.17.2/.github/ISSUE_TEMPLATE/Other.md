---
name: Other
about: Something else

---

<!-- Bug reports and Feature requests must use other templates, or will be closed -->
<!-- Please ask questions on StackOverflow or the webpack Gitter (https://gitter.im/webpack/webpack). -->
<!-- Issues which contain questions or support requests will be closed. -->
